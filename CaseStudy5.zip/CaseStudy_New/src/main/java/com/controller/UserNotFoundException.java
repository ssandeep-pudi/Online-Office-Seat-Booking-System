package com.controller;

public class UserNotFoundException extends Exception{
	public UserNotFoundException(String m)
	{
		super(m);
	}
}
