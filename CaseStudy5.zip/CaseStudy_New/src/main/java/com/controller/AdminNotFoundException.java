package com.controller;

public class AdminNotFoundException extends Exception {
	public AdminNotFoundException(String m)
	{
		super(m);
	}
}
