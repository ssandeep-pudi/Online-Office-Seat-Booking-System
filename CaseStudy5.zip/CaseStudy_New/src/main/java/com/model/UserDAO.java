//package com.model;
//
//import java.util.List;
//
//import org.springframework.stereotype.Component;
//
//@Component
//public interface UserDAO {
//	public List<Seats> seatList();
//	public List<FloorDetails>  floorList();
//	public List<Office_Info> offcList();
//	public List<User_org> userList();
//	public User_org saveUser(User_org user);
//	public void updateMail(User_org user, String mail);
//	// request cancellation
//	// history
//	
//}
